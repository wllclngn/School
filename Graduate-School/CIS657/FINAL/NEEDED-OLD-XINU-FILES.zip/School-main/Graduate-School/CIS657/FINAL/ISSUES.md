# ISSUES.md

WINDOWS: Pathing.
Templates are not dynamic enough if they are not being remade.
