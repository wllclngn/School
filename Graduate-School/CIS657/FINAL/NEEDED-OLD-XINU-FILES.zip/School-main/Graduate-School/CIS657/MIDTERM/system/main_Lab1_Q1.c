/* hello.c - main - I love vi/Vim, Dr. Mo! */

#include <xinu.h>
/* main: Say hello, EXIT. */
void main(void)
{
printf("Hell, world!\n");
}
