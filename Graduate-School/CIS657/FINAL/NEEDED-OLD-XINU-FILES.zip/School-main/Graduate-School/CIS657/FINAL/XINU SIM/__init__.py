"""
xinu_sim - Cross-platform build system for XINU operating system
"""

__version__ = "1.0.0"
