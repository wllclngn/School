shellcmd xsh_create(int, char*[]);
shellcmd xsh_createsleep(int, char*[]);
shellcmd xsh_psready(int, char*[]);
shellcmd xsh_wait(int, char*[]);
shellcmd xsh_signaln(int, char*[]);
shellcmd xsh_resumen(int, char*[]);