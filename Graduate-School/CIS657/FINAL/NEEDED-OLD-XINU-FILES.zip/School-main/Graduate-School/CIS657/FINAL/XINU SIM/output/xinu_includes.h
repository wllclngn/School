/* xinu_includes.h - Wrapper for XINU code compilation.
 * Generated on: 2025-06-18 09:52:03 by mol
 */
#ifndef _XINU_INCLUDES_H_ 
#define _XINU_INCLUDES_H_

#define _CRT_SECURE_NO_WARNINGS 
#define XINU_SIMULATION        

/* Include our minimal defs */
#include "xinu_stddefs.h" 

#endif /* _XINU_INCLUDES_H_ */
